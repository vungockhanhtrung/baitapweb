# Bảng Tổng Hợp Kiểm Thử & Minh Chứng (A3)
- **Sinh viên:** Vũ Ngọc Khánh Trung – MSV: `2071020209` – Lớp: `CNTT 20-04`

## 1. Ma trận kiểm thử Responsive & Chức năng
| Hạng mục kiểm thử | Thao tác thực hiện | Kết quả mong đợi | Kết quả thực tế | Trạng thái |
| :--- | :--- | :--- | :--- | :--- |
| **Cấu trúc HTML5** | Kiểm tra tab Elements trong DevTools | Có đúng 1 `<h1>`, 1 `<main>`, ảnh có `alt` | Đúng cấu trúc, không lỗi cú pháp | Đạt |
| **Màn hình hẹp (320px)** | Đặt viewport `320px` trên DevTools | Menu tự xuống dòng, bố cục 1 cột, không cuộn ngang | Hiển thị 1 cột rõ ràng, `scrollWidth === innerWidth` | Đạt |
| **Sát điểm vỡ B1 (639px / 640px)** | Thay đổi chiều rộng từ `639px` lên `640px` | Tại `639px` xếp 1 cột; tại `640px` chuyển sang 2 cột | Chuyển cột chính xác tại mốc `640px` | Đạt |
| **Sát điểm vỡ B2 (959px / 960px)** | Thay đổi chiều rộng từ `959px` lên `960px` | Tại `959px` xếp 2 cột; tại `960px` chuyển sang 3 cột | Chuyển cột chính xác tại mốc `960px` | Đạt |
| **Điều hướng bàn phím** | Bấm phím `Tab` liên tục qua menu, card, form | Xuất hiện viền focus màu cam (`#d97706`) rõ nét | Viền focus hiển thị đầy đủ, không bị cắt | Đạt |
| **Form: Trường rỗng** | Bấm nút gửi khi chưa nhập dữ liệu | Trình duyệt chặn gửi và báo lỗi ở ô Họ tên | Hiển thị thông báo bắt buộc nhập liệu | Đạt |
| **Form: Sai định dạng** | Nhập email `trung@` và nội dung ngắn `"Chào"` | Trình duyệt báo lỗi sai định dạng email và độ dài | Hiển thị viền đỏ (`:user-invalid`) và chặn gửi | Đạt |
| **Form: Dữ liệu hợp lệ** | Nhập đủ Họ tên, Email chuẩn, Nội dung > 10 ký tự | Chuyển sang trang `ket-qua.html` kèm query string | Chuyển trang thành công, URL chứa dữ liệu GET | Đạt |
| **Triển khai GitHub Pages** | Mở URL công khai bằng cửa sổ ẩn danh | Trang tải đủ HTML, CSS và SVG (HTTP Status `200`) | Hoạt động ổn định, không có lỗi `404` | Đạt |

## 2. Đối chiếu phiên bản (Local – Repo – Deploy – URL)
- **Nhánh xuất bản:** `main` (`/root`)
- **Tag phiên bản:** `v8`
- **Ghi chú:** Toàn bộ ảnh chụp màn hình kiểm thử (`before-320.png`, `after-320.png`, `devtools-network-200.png`, `form-validation.png`) được lưu trữ kèm theo trong thư mục `docs/screenshots/` khi nộp gói bài trên LMS.